Page({
  data: {
    navs: [{ style: 'orchestral', navimg: '../images/pic_style_orchestra.png' },
    { style: 'electronic', navimg: '../images/pic_style_electronic.png' },
    { style: 'pop', navimg: '../images/pic_style_popular.png' }],
    indicatorDots: false,
    circular: true,
    current: 0,
    index: 0,
    duration: 500,
    userId: '',
    sessionId: '',
    styleId: '',
    style: '',
    isChecked: false
  },

  generate: function () {
    var _this = this;
    console.log(_this.data.index);
    var styleid = uuid();
    wx.setStorage({ key: 'styleId', data: styleid });

    if (_this.data.index == 0) {
      _this.setData({
        style: 'orchestral',
        styleId: styleid
      })
    } else if (_this.data.index == 1) {
      _this.setData({
        style: 'electronic',
        styleId: styleid
      })
    } else {
      _this.setData({
        style: 'pop',
        styleId: styleid
      })
    }

    wx.setStorage({ key: 'style', data: _this.data.index });

    wx.navigateTo({
      url: '../producing/producing'
    })

    wx.request({
      url: "http://103.28.215.253:10515/aimusic-server/music/generateStyleMusic",
      data:
      {
        userId: _this.data.userId,
        sessionId: _this.data.sessionId,
        styleId: _this.data.styleId,
        style: _this.data.style,
        bpm: '0'
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
        wx.redirectTo({
          url: '../listening/listening',
        })
      },
      fail: function (res) {
        console.log(res);
      }
    })
  },

  swiperChange(e) {
    let current = e.detail.current;
    console.log(current, this.data.index, this.data.current)
    this.setData({
      index: current
    })
    console.log(current, this.data.index, this.data.current)
  },

  serviceSelection() {
    this.setData({
      isChecked: true
    })
  },

  onLoad: function (options) {
    var _this = this;

    wx.getStorage({
      key: 'userId',
      success: function (res) {
        _this.setData({
          userId: res.data
        })
        console.log('userId is ' + _this.data.userId)
      },
    })

    wx.getStorage({
      key: 'sessionId',
      success: function (res) {
        _this.setData({
          sessionId: res.data
        })
        console.log('sessionId is ' + _this.data.sessionId)
      },
    })
  },

  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '人人都能成为作曲家',
      desc: '展现你的声音的无限魅力!',
      path: '/pages/share/share',
      success: function (res) {
        // 转发成功
        console.log('转发成功');
      },
      fail: function (res) {
        // 转发失败
        console.log('转发失败');
      }
    }
  }
})
function uuid() {
  var s = [];
  var hexDigits = "0123456789abcdef";
  for (var i = 0; i < 36; i++) {
    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
  }
  s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
  s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
  s[8] = s[13] = s[18] = s[23] = "-";

  var uuid = s.join("");
  return uuid;
}
var timeCount = 0;
var duringTime = 0;
const recorderManager = wx.getRecorderManager();
const innerAudioContext = wx.createInnerAudioContext();
var app = getApp()
var interval;
var varName;
var ctx = wx.createCanvasContext('canvasArcCir');
var clientWidth = wx.getSystemInfoSync().screenWidth;
var tempFilePath;
var isRecording = false;
var isPauseFlag = false;
var isNotReload = true;
const options = {
  duration: 10500,
  sampleRate: 16000,
  numberOfChannels: 1,
  encodeBitRate: 96000,
  format: 'mp3',
  frameSize: 50,
};
Page({
  data: {
    isSpeaking: false,
    isListen: false,
    listening: false,
    canSend: false,
    pausing: false,
    scaleData: {},
    animationMiddleHeaderItem: {},
    startTime: 0,
    endTime: 0,
    count: 0,
    userId: '',
    sessionId:'',
    musicFile: '',
    resultTxt: '点击开始录入3~10秒的歌声'
  },

  generate: function () {
    console.log('generate fn');
    var _this = this;
    innerAudioContext.stop();
    if (this.data.isSpeaking) {
      this.setData({
        resultTxt: '录音中不可以分心哦'
      })
    } else {
      if (this.data.canSend) {
        wx.saveFile({
          tempFilePath: _this.tempFilePath,
          success: function (res) {
            var savedFilePath = res.savedFilePath
            console.log("本地录音文件: " + savedFilePath)
          }
        })
        wx.redirectTo({
          url: '../producing/producing'
        })
        wx.getSavedFileList({
          success: function (res) {
            _this.data.musicFile = res.fileList[0].filePath
            wx.uploadFile({
              url: "http://103.28.215.253:10515/aimusic-server/music/uploadOriginalMusicWithFile",
              filePath: _this.data.musicFile,
              name: 'musicFile',
              formData:
              {
                "userId": _this.data.userId,
                "sessionId": _this.data.sessionId,
                "musicType": "mp3",
                "bpm": "0"
              },
              header: {
                'content-type': 'multipart/form-data'
              },
              success: function (res) {
                console.log('singing返回' + res.data);
                let status = JSON.parse(res.data).status;
                if(status == 'success'){
                  wx.redirectTo({
                    url: '../listening/listening',
                  })
                } else {
                  wx.showModal({
                    title: '出错啦',
                    content: '你的声音没有录制成功哦，请确认并返回重新录制',
                    success: function (res) {
                      if (res.confirm) {
                        wx.redirectTo({
                          url: '../singing/singing',
                        })
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
                }
              },
              fail: function (res) {
                console.log(res);
              }
            })
            console.log(res.fileList[0].filePath)
          }
        })
      } else {
        this.setData({
          resultTxt: '你还没有开始录音哦'
        })
      }
    }
  },

  recircle: function () {
    console.log('recircle fn');
    isRecording = false;
    isNotReload = false;
    tempFilePath = '';
    clearInterval(varName);
    clearInterval(this.timer);
    recorderManager.stop();
    innerAudioContext.stop();
    innerAudioContext.destroy();
    isPauseFlag = false;
    isNotReload = true;
    wx.reLaunch({
      url: '../singing/singing'
    })
  },

  onReady: function(){
    wx.setStorage({ key: 'style', data: 'default' });
    wx.setStorage({ key: 'styleId', data: 'default' }); 
    console.log('onReady fn')
    this.setData({
      isSpeaking: false,
      isListen: false,
      listening: false,
      canSend: false,
      pausing: false
    })
  },

  onShow: function (){
    console.log('onShow fn')
    var circleCount = 0;
    this.animationMiddleHeaderItem = wx.createAnimation({
      duration: 500,    // 以毫秒为单位  
      timingFunction: 'linear',
      delay: 0,
      transformOrigin: '50% 50%',
      success: function (res) {
      }
    });
    setInterval(function () {
      if (circleCount % 2 == 0) {
        this.animationMiddleHeaderItem.scale(1.3).step();
      } else {
        this.animationMiddleHeaderItem.scale(1.0).step();
      }
      this.setData({
        animationMiddleHeaderItem: this.animationMiddleHeaderItem.export()
      });
      circleCount++;
      if (circleCount == 1000) {
        circleCount = 0;
      }
    }.bind(this), 500);  
  },

  onLoad: function (options) {
    var sessionId = uuid();
    wx.setStorage({ key: 'sessionId', data: sessionId });

    var _this = this;
    getRecordSetting(wx, _this);

    wx.getSavedFileList({
      success: function (res) {
        if (res.fileList.length > 0) {
          for (let i = 0; i < res.fileList.length; i++)
          wx.removeSavedFile({
            filePath: res.fileList[i].filePath,
            complete: function (res) {
              console.log(res)
            }
          })
        }
      }
    })

    wx.getStorage({
      key: 'userId',
      success: function(res) {
        _this.setData({
          userId: res.data
        })
        console.log('userId is ' + _this.data.userId)
      },
    })

    wx.getStorage({
      key: 'sessionId',
      success: function (res) {
        _this.setData({
          sessionId: res.data
        })
        console.log('sessionId is ' + _this.data.sessionId)
      },
    })

    recorderManager.onPause(() => {
      console.log('onPause回调触发');
      isRecording = false;
      clearTimeout(_this.timer);
      console.log('onPause clearTimeout');
      _this.setData({
        isSpeaking: false,
        endTime: new Date().getTime(),
        resultTxt: '时间太短啦，请录入大于3秒的歌声吧'
      });
      timeCount = 0;
      console.log('onPause end');
    })

    recorderManager.onStart(() => {
      console.log('onStart回调触发')
      clearTimeout(_this.timer);
      _this.setData({
        isSpeaking: true,
        startTime: new Date().getTime()
      });
      timeCount = 0;
      speaking.call(_this);
    })

    recorderManager.onStop(function (res) {
      console.log('onStop回调触发');
      console.log('isPauseFlag: ' + isPauseFlag);
      isRecording = false;
      clearTimeout(_this.timer); 
      if (!isPauseFlag){
        if (!isNotReload){
          console.log('isNotReload is false');
          isNotReload = true;
          return;
        }
        _this.tempFilePath = res.tempFilePath;
        console.log('临时录音文件' + _this.tempFilePath);
        innerAudioContext.src = _this.tempFilePath;
        _this.setData({
          isSpeaking: false,
          isListen: true,
          canSend: true,
          endTime: new Date().getTime()
        });
      }else{
        console.log('isPauseFlag true');
        _this.setData({
          isSpeaking: false,
          endTime: new Date().getTime(),
          resultTxt: '时间太短啦，请录入大于3秒的歌声吧'
        });
        isPauseFlag = false;
      }
      
      timeCount = 0;
    })

    innerAudioContext.onError((res) => {
      isRecording = false;
      console.log(res.errMsg);
      console.log(res.errCode);
      wx.showModal({
        title: '出错啦',
        content: '你的声音没有录制成功哦，请确认并返回重新录制',
        success: function (res) {
          if (res.confirm) {
            wx.redirectTo({
              url: '../singing/singing',
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    });
    
    innerAudioContext.onEnded(() => {
      _this.setData({
        listening: false,
        pausing: false
      });
    });
  },
  
  playing: function () {
   this.setData({
      listening: true,
      pausing: false
    });
    innerAudioContext.play();
  },

  puasing: function(){
   this.setData({
      listening: false,
      pausing: true
    });
    innerAudioContext.pause();
  },

  stopping: function () {
    console.log('stopping fn');
    isRecording = false;
    var _this = this;
    clearInterval(varName);
    clearTimeout(this.timer);
    duringTime = this.data.count * 1000;
    console.log(duringTime)
    if (duringTime >= 3000) {
      console.log('recorderManager stop');
      isPauseFlag = false;
      isNotReload = true;
      recorderManager.stop();
    } else {
      // console.log('recorderManager pause');
      // recorderManager.pause();
      isPauseFlag = true;
      recorderManager.stop();
    }
  },

  recording: function(){
    
    var _this = this;
    _this.setData({
      resultTxt: ''
    })
    if (_this.data.getRecord) {  //已开启录音权限
      console.log('tap时已开启录音权限');
      if(!isRecording){
        isRecording = true;
        recorderManager.start(options);
      }
      // recorderManager.stop();
    } else {
      console.log('用户点击了录音按钮，但之前没授权录音权限，所以需引导用户开启');
      getRecordSetting(wx, _this)
    }

    clearInterval(varName);
    var step = 1, startAngle = 1.5 * Math.PI, endAngle = 0;
    var animation_interval = 180, n = 60;
    var animation = function () {
      if (step <= n) {
        endAngle = step * 2 * Math.PI / n + 1.5 * Math.PI;
        drawArc(startAngle, endAngle);
        step++;
      } else {
        console.log('step: '+step);
        clearInterval(varName);
      }
    };
    varName = setInterval(animation, animation_interval);
  }
})
function speaking() {
  clearTimeout(this.timer);
  var _this = this;
  console.log('时间计时器开始计时: ' + timeCount);
  this.timer = setTimeout(function () {
    var count = timeCount;
    timeCount = (parseFloat(count) + 0.1).toFixed(1);
    _this.setData({
      count: timeCount
    });
    speaking.call(_this);
  }, 100);
}
function getRecordSetting(wx, _this) {
  console.log('获取用户是否开启录音权限');
  wx.getSetting({
    success(res) {
      console.log('获取用户是否开启录音权限成功');
      if (!res.authSetting['scope.record']) {
        console.log('是否开启录音权限: false');
        wx.authorize({
          scope: 'scope.record',
          success(res) {
            // 用户已经同意，后续调用不会弹窗询问
            console.log('用户同意开启录音权限');
            console.log(res)
            _this.setData({ getRecord: true })
          },
          fail(res) {
            console.log('用户不同意开启录音权限');
            console.log(res);
            wx.openSetting({
              success: (res) => {
                console.log('openSetting record');
                console.log(res.authSetting['scope.record']);
              }
            });
          }
        });
      } else {
        console.log('是否开启录音权限: true');
        _this.setData({ getRecord: true })
      }
    },
    fail(res) {
      console.log('获取用户是否开启录音权限 fail');
      console.log(res);
    }
  });
}
function uuid() {
  var s = [];
  var hexDigits = "0123456789abcdef";
  for (var i = 0; i < 36; i++) {
    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
  }
  s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
  s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
  s[8] = s[13] = s[18] = s[23] = "-";

  var uuid = s.join("");
  return uuid;
}
function drawArc(s, e) {
  ctx.setFillStyle('white');
  ctx.clearRect(0, 0, clientWidth *150 / 750, clientWidth *150 / 750);
  ctx.draw();
  var x = clientWidth * 75 / 750, y = clientWidth * 75 / 750, radius = clientWidth * 72 / 750;
  ctx.setLineWidth(clientWidth * 3 / 750);
  ctx.setStrokeStyle('#ed215e');
  ctx.setLineCap('round');
  ctx.beginPath();
  ctx.arc(x, y, radius, s, e, false);
  ctx.stroke()
  ctx.draw()
}
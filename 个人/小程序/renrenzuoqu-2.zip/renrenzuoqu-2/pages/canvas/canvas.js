// pages/canvas/cnavas.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    readingContentArr: [
      '30秒，解锁你被埋没的音乐天赋！',
      '30秒，作出属于你的音乐',
      '快来试试最火的作曲小程序！',
      '你也要来发布新歌吗？',
      '你也可以是作曲家！马上行动吧！',
      '还不快来一起作曲？'
    ],
    readingContent: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var userInfo = wx.getStorageSync('userInfo') || {};
    console.log(userInfo)
    var username = userInfo.nickName || '';

    var _this = this;
    _this.setData({
      readingContent: _this.data.readingContentArr[parseInt(Math.random() * _this.data.readingContentArr.length)]
    });

    const ctx = wx.createCanvasContext("myCanvas")
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, 375, 603)
    ctx.drawImage("../images/bg_1.png", 0, 0, 375, 603)

    ctx.setFontSize(16);
    ctx.setFillStyle("#ed215e");
    ctx.fillText('你的网红好友' + username + '发布了一首新歌!', (375 - ctx.measureText('你的网红好友' + username + '发布了一首新歌!').width) / 2, 380)

    ctx.setFontSize(16);
    ctx.setFillStyle("#ed215e");
    ctx.fillText(_this.data.readingContent, (375 - ctx.measureText(_this.data.readingContent).width) / 2, 420)

    ctx.save();
    ctx.setLineWidth(1);
    ctx.setFillStyle('#eaeaea');
    // ctx.setLineCap('round');
    ctx.beginPath();
    ctx.arc(187.5, 500, 51, 0, 2 * Math.PI, false);
    ctx.fill();
    ctx.clip();
    const qrImgSize = 100
    ctx.drawImage("../images/code.png", (375 - qrImgSize) / 2, 450, qrImgSize, qrImgSize)
    ctx.draw(true, function () {
      console.log("draw callback success")
      wx.canvasToTempFilePath({
        x: 0,
        y: 0,
        width: 375,
        height: 603,
        destWidth: 750,
        destHeight: 1206,
        canvasId: 'myCanvas',
        success: function (res) {
          console.log("get tempfilepath(success) is:", res.tempFilePath)
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success(res) {
              console.log(res);
              wx.showModal({
                title: '保存成功！',
                content: '分享方法：切换到朋友圈/QQ/微博上，分享时选择此图即可',
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  }
                }
              })
            },
            fail(res) {
              console.log(res)
              wx.showModal({
                title: '啊哦',
                content: '你不要留着给朋友们看看吗',
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })
            }
          })
        }
      })
    })
  },

  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '人人都能成为作曲家',
      desc: '展现你的声音的无限魅力!',
      path: '/pages/share/share',
      success: function (res) {
        // 转发成功
        console.log('转发成功');
      },
      fail: function (res) {
        // 转发失败
        console.log('转发失败');
      }
    }
  }})
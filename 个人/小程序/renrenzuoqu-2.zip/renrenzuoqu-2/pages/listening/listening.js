const innerAudioContext = wx.createInnerAudioContext();
var tempFilePath;
var rotSet;

Page({
  data: {
    showModal: false,
    isRotate: false,
    rotate: 0,
    styletitle: '',
    userId: '',
    sessionId: '',
    styleId: ''
  },

  close :function(){
    this.setData({
      showModal: false
    })
  },

  previewImage: function () {
    wx.navigateTo({
      url: '../canvas/canvas',
    })
  },

  shareFn: function () {
    console.log('shareFn');
  },

  onShareAppMessage: function (res) {
    let userInfo = wx.getStorageSync('userInfo') || {};
    let username = userInfo.nickName || '';
    let picurl = userInfo.avatarUrl || '';

    let _this = this;
    let infos = _this.data.userId + ',' + _this.data.sessionId + ',' + _this.data.styletitle + ',' + username + ',' + picurl + ',' + _this.data.styleId;
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '邀请你的朋友来参与创作',
      desc: '让他们听听你的大作!',
      path: '/pages/share/share?infos=' + infos,
      success: function (res) {
        // 转发成功
        console.log('转发成功');
      },
      fail: function (res) {
        // 转发失败
        console.log('转发失败');
      }
    }
  },

  onPause: function(){
    this.setData({
      isRotate: false
    });
    innerAudioContext.pause();
    clearInterval(rotSet);
  },

  onPlay: function () {
    this.setData({
      isRotate: true
    });
    console.log(innerAudioContext.src)
    console.log(innerAudioContext.duration)

    innerAudioContext.play();

    clearInterval(rotSet);
    rotSet = setInterval(() => {
      this.setData({
        rotate: 1 + this.data.rotate,
      });
    }, 24); 
  },

  popUp: function () {
    this.setData({
      showModal: true
    })
  },

  bindBackTap: function () {
    innerAudioContext.stop();
    wx.redirectTo({
      url: '../singing/singing'
    })
  },

  bindStyleTap: function () {
    innerAudioContext.stop();
    wx.navigateTo({
      url: '../style/style'
    })
  },

  onLoad: function (options) {
    var _this = this;

    wx.getStorage({
      key: 'userId',
      success: function (res) {
        _this.setData({
          userId: res.data
        })
        console.log('userId is ' + _this.data.userId)
        wx.getStorage({
          key: 'sessionId',
          success: function (res) {
            _this.setData({
              sessionId: res.data
            })
            console.log('sessionId is ' + _this.data.sessionId)
            wx.getStorage({
              key: 'style',
              success: function (res) {
                _this.setData({
                  styletitle: res.data
                })
                console.log('style is ' + _this.data.styletitle)
                wx.getStorage({
                  key: 'styleId',
                  success: function (res) {
                    _this.setData({
                      styleId: res.data
                    })
                    console.log('styleId is ' + _this.data.styleId)
                    innerAudioContext.src = 'http://103.28.215.253:10515/aimusic-server/music/downloadStyleMusicMp3?userId=' + _this.data.userId + '&sessionId=' + _this.data.sessionId + '&styleId=' + _this.data.styleId;
                  },
                })
              },
            })
          },
        })
      },
    })

    innerAudioContext.onError((res) => {
      console.log(res.errMsg);
      console.log(res.errCode);
    });

    innerAudioContext.onEnded(() => {
      _this.setData({
        isRotate: false
      });
      clearInterval(rotSet);
    });
  }
})
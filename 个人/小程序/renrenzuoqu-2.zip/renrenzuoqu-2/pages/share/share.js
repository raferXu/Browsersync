const app = getApp()
const innerAudioContext = wx.createInnerAudioContext();
var rotSet;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showModal: false,
    animationData: {},
    isRotate: false,
    playing: false,
    rotate: 0,
    styletitle: '',
    userId: '',
    sessionId: '' ,
    nickName: '',
    avatarUrl: '',
    styleId: ''
 },

  previewImage: function () {
    wx.navigateTo({
      url: '../canvas/canvas',
    })
  },

  shareFn: function () {
    console.log('shareFn');
  },

  onPause: function () {
    this.setData({
      isRotate: false
    });
    innerAudioContext.pause();
    clearInterval(rotSet);
  },

  onPlay: function () {
    let _this = this;
    this.setData({
      isRotate: true
    });
    innerAudioContext.play();
    clearInterval(rotSet);

    rotSet = setInterval(() => {
      _this.setData({
        rotate: 1 + this.data.rotate,
      });
    }, 24); 
  },

  popUp: function () {
    this.setData({
      showModal: true
    })
  },

  close: function () {
    this.setData({
      showModal: false
    })
  },

  bindBackTap: function () {
    wx.redirectTo({
      url: '../singing/singing'
    })
  },

  onLoad: function (options) {
    console.log(options.infos)
    let sendinfo = options.infos.split(',');
    console.log(sendinfo)
    this.data.userId = sendinfo[0];
    this.data.sessionId = sendinfo[1];
    this.data.styleId = sendinfo[5];
    this.setData({
      styletitle: sendinfo[2],
      nickName: sendinfo[3],
      avatarUrl: sendinfo[4]
    })

    // this.data.styletitle = sendinfo[2];
    // this.data.nickName = sendinfo[3];
    // this.data.avatarUrl = sendinfo[4];

    innerAudioContext.src = 'http://103.28.215.253:10515/aimusic-server/music/downloadStyleMusicMp3?userId=' + this.data.userId + '&sessionId=' + this.data.sessionId + '&styleId=' + this.data.styleId;
    innerAudioContext.onError((res) => {
      console.log(res.errMsg);
      console.log(res.errCode);
    });

    innerAudioContext.onEnded(() => {
      this.setData({
        isRotate: false
      });
      clearInterval(rotSet);
    });
  }
})
Page({
  data: {
    isCode:'',
    userInfo: {},
    musicList: {},
    musicInfo: {},
    hasMusic: 0,
    shaft5: '',
    isPlay: 0
  },
  goToPlay: function () {
    var userInfo = wx.getStorageSync('userInfo') || {};
    var tempFilePath = userInfo.file;
    return tempFilePath;
  },
  goNext: function (res) {

    var starTextArr = [
      [
        '魅力值爆棚哦！快去勾搭男神/女神吧！',
        '嘘！不要说话，我会融化的～',
        '听你的声音，耳朵会怀孕！'
      ],[
        '你的声音像美酒，让我沉醉！',
        '想把你的声音设成闹钟，叫醒我的耳朵！',
        '你连呼吸的声音都很性感!'
      ],[
        '你是个既能靠颜值又能靠声音吃饭的人！',
        '你独特的声音，定会在人群中脱颖而出！',
        '魅力不低哦，你的声音被我单曲循环了！'
      ]
    ];

    var songArr = {
      '张学友': '吻别',
      '陈奕迅': '浮夸',
      '周杰伦': '青花瓷',
      '李健': '贝加尔湖畔',
      '王力宏': '唯一',
      '薛之谦': '演员',
      '李宗盛': '山丘',
      '汪峰': '北京北京',
      '林俊杰': '修炼爱情',
      '王俊凯': '青春修炼手册',

      '邓紫棋': '泡沫',
      '孙燕姿': '遇见',
      '邓丽君': '夜来香',
      '王菲': '旋木',
      '田馥甄': '小幸运',
      '蕾哈娜': 'Diamond',
      '张韶涵': '欧若拉',
      '梁静茹': '勇气',
      '张碧晨': '凉凉',
      '林忆莲': '至少还有你'
    };
    // var voiceType = res.voiceQuality;
    var voiceType = '';
    var charm = parseInt(res.star) || parseInt(3+Math.random()*2);
    var star1 = res.movieName;
    var star1Val = parseInt((res.movier=='NaN'?Math.random()*100:res.movier));
    var star2 = res.singerName;
    var star2Val = parseInt((res.songer=='NaN'?Math.random()*100:res.songer));
    var topStar = star1Val > star2Val ? star1 : star2;
    var starAttrObj = {
      '霸道总裁音': ['刘德华','张学友','彭于晏'],
      '饱经沧桑音': ['李宗盛', '汪峰','黄渤'],
      '逗比戏精音': ['陈赫','王宝强'],
      '阳光暖男音': ['李健', '王力宏','吴亦凡'],
      '雌雄同体音': ['张国荣','薛之谦'],
      '幼稚小奶音': ['鹿晗','王俊凯'],
      '时尚潮流音': ['周杰伦', '陈奕迅','林俊杰'],
      '撩人男神音': ['胡歌','李易峰'],
      '绝美天籁音': ['王菲','邓丽君'],
      '高冷女王音': ['巩俐', '范冰冰','林忆莲'],
      '欧美豪放音': ['邓紫棋','蕾哈娜'],
      '温柔女神音': ['赵丽颖', '梁静茹','田馥甄'],
      '性感主播音': ['迪丽热巴','张碧晨'],
      '清纯学妹音': ['新垣结衣', '孙燕姿','杨幂'],
      '甜美萝莉音': ['张韶涵','杨颖'],
      '灭绝师太音': ['俞飞鸿'],
      '古典女神音': ['邱淑贞','王祖贤']
    };
    for (var k in starAttrObj){
      for (var i=0; i<starAttrObj[k].length; i++){
        if (topStar == starAttrObj[k][i]){
          voiceType = k;
          break;
        }
      }
    }
    var allLang = [[
      '哇塞，你都可以去给ta做职业配音了！',
      '莫非你们是失散多年的亲兄弟？',
      '你跟他的声音还是有几分神似啦！',
      '没关系，好在你们同为人类的声音……'
    ],[
      '哇！快去高歌一曲ta的【'+songArr[star2]+'】，大家一定会认为是原唱！',
      '快去录一首ta的【'+songArr[star2]+'】发给小伙伴们吧~',
      '你与ta还是有一些相似，但还需训练哦！',
      '高处不胜寒，歌星们都比不上你的声音独特~'
    ]];
    var scoreJson = {
      'db': parseInt((res.douBiScore=='NaN'?Math.random()*100:res.douBiScore)),
      'll': parseInt((res.luoLiScore=='NaN'?Math.random()*100:res.luoLiScore)),
      'nw': parseInt((res.nvWangScore=='NaN'?Math.random()*100:res.nvWangScore)),
      'nn': parseInt((res.nuanNanScore=='NaN'?Math.random()*100:res.nuanNanScore)),
      'xg': parseInt((res.xingGanScore=='NaN'?Math.random()*100:res.xingGanScore)),
      'yg': parseInt((res.yangGangScore=='NaN'?Math.random()*100:res.yangGangScore))
    };
    var random = parseInt(Math.random()*3);
    var starText = (charm==5) ? starTextArr[0][random] : ((charm==4) ? starTextArr[1][random] : starTextArr[2][random]);
    var lang1 = star1Val>80?allLang[0][0]:star1Val>60?allLang[0][1]:star1Val>40?allLang[0][2]:allLang[0][3];
    var lang2 = star2Val>80?allLang[1][0]:star2Val>60?allLang[1][1]:star2Val>40?allLang[1][2]:allLang[1][3];

    var finalData = {
      'prop' : voiceType,
      'charm' : charm,
      'starText': starText,
      'lang': [lang1,lang2],
      'valueArr': [star1Val,star2Val],
      'starArr' : [star1,star2],
      'seriesData': [scoreJson['ll'],scoreJson['xg'],scoreJson['nw'],scoreJson['nn'],scoreJson['db'],scoreJson['yg']],
      'categories' : ['萝莉 '+scoreJson['ll']+' %', '性感 '+scoreJson['xg']+' %', '女王 '+scoreJson['nw']+' %', '暖男 '+scoreJson['nn']+' %', '逗比 '+scoreJson['db']+' ％', '阳刚 '+scoreJson['yg']+' %']
    };
    var userInfo = wx.getStorageSync('userInfo') || {};
    userInfo.result = finalData;
    wx.setStorageSync('userInfo', userInfo);
    wx.redirectTo({
      url: '../result/result'
    })
  },
  onShow: function () {
    console.log(this.isPlay);  //undefined 2
    console.log('analysing page show');
    this.setData({
      shaft5: 'shaft5'
    });
  },
  onReady: function () {  //返回上一页不会触发
    console.log(this.isPlay);  //undefined 3
    console.log('analysing page ready');
  },
  onHide: function () {
    console.log('analysing page hide');
    this.setData({
      shaft5: ''
    });
  },
  onLoad: function () {
    wx.getStorage({
      key: 'isCode',
      success: function (res) {
        _this.setData({
          isCode: res.data
        })
        console.log('code is ' + _this.data.isCode)
      },
    })

    console.log(this.isPlay);  //undefined 1
    console.log('analysing page onload');
    var _this = this;
    setTimeout(function () {
      // var urls = app.globalData.urls + "/Web/UpVoice";
      var filePath = _this.goToPlay();
      //var urls = "https://test-vprc-core.pingan.com.cn:56443/vprc_core_portal/rest/api/weixin/check_voice";
      var urls = "https://vprc-core.pingan.com.cn/vprc_core_portal/rest/api/weixin/check_voice";
      wx.uploadFile({
        url: urls,
        filePath: filePath,
        name: 'voice_path',
        formData:{
          'appId': '10041',
          'scene': 'chat_cli',
          'userId': '10041',
          // 'code': _this.data.isCode
        },
        header: {
          'content-type': 'multipart/form-data'
        },
        success: function (res) {
          console.log('success');
          console.log(res);
          var statusCode = res.statusCode;
          if(statusCode==200){
            var response = res.data;
            var responseJSON = JSON.parse(response);
            if(responseJSON.responseCode=='00'){
              console.log('操作成功');
              var data = responseJSON.data;
              if(data.returnCode=='200'){
                var returnData = data.returnData;
                console.log(returnData);
                _this.goNext(returnData);
              }else if(data.returnCode=='302'){
                console.log('returnCode: ' + data.returnCode);
                const innerAudioContext = wx.createInnerAudioContext();
                innerAudioContext.autoplay = true;
                innerAudioContext.src = filePath;
                innerAudioContext.onPlay(function(){
                  console.log('开始播放');
                  wx.reLaunch({
                    url: '../userName/userName'
                  })
                });
                innerAudioContext.onError(function(res){
                  console.log(res.errMsg);
                  console.log(res.errCode)
                });



              }else{
                console.log('returnCode: '+data.returnCode);
                wx.showModal({
                  title: '提示',
                  content: "系统繁忙，请稍后重试。",
                  showCancel: false,
                  success: function (res) {
                    console.log('系统繁忙 showModal success');
                    wx.reLaunch({
                      url: '../userName/userName'
                    })
                  }
                });
                wx.hideToast();
              }
            }else{
              console.log('responseCode: '+responseJSON.responseCode);
              wx.showModal({
                title: '提示',
                content: "1网络请求失败，请确保网络是否正常"+responseJSON.responseCode,
                showCancel: false,
                success: function (res) {
                  console.log('responseCode错误 showModal success');
                  wx.reLaunch({
                    url: '../userName/userName'
                  })
                }
              });
              wx.hideToast();
            }

          }else{
            console.log('statusCode错误，错误码是: '+statusCode);
            wx.showModal({
              title: '提示',
              content: "2网络请求失败，请确保网络是否正常"+statusCode,
              showCancel: false,
              success: function (res) {
                console.log('statusCode错误 showModal success');
                wx.reLaunch({
                  url: '../userName/userName'
                })
              }
            });
            wx.hideToast();
          }
        },
        fail: function (res) {
          console.log('upload fail');
          console.log(res);
          wx.showModal({
            title: '提示',
            content: "微信接口上传失败",
            showCancel: false,
            success: function (res) {
              console.log('fail showModal success');
              wx.reLaunch({
                url: '../userName/userName'
              })
            }
          });
          wx.hideToast();
        }
      });
    },1000);

  }
});

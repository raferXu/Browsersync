var timeCount = 0;
var duringTime = 0;
const recorderManager = wx.getRecorderManager();
const options = { 
  duration: 30000,
  sampleRate: 8000,
  numberOfChannels: 1,
  encodeBitRate: 24000,
  format: 'mp3'
};
Page({
  data: {
    getRecord: false,
    countShow: false,
    isSpeaking: false,
    startTime: 0,
    endTime: 0,
    voices: [],
    count: 0,
    resultTxt: '',
    readingTitle: '戏精附身的宝宝可以念出下面的台词喔!',
    readingTips: '点击按钮录入大于10秒的录音\n完成后再次点击按钮结束录音',
    readingTips2: '请点击按钮 结束录音',
    readingContentArr: [
      '也许每一个男子全都有过这样的两个女人，至少两个。娶了红玫瑰，久而久之，红的变了墙上的一抹蚊子血，白的还是”床前明月光”；娶了白玫瑰，白的便是衣服上沾的一粒饭黏子，红的却是心口上一颗朱砂痣。',
      '因为了解到世界的广大与多元，并觉知到自我的局限与狭隘，所以允许自己不懂得他人，也允许他人不懂得自己；所以不试图凌驾他人的意志，也不轻易置身于他人定立的评价体系—这大概就是最自由的孤独，最温柔的叛逆。',
      '从某种意义上来看，世间一切都是遇见。就像冷遇见暖，就有了雨；春遇见冬，就有了岁月；天遇见地，有了永恒；人遇见人，有了生命。',
      '愿你慢慢长大，愿你有好运，如果没有，希望你在不幸中学会慈悲；愿你被很多人爱，如果没有，希望你在寂寞中学会宽容。',
      '当面临两个选择时，抛硬币总能奏效，并不是因为它总能给出对的答案，而是在你把它抛在空中的那一秒里，你突然就知道，你希望的结果是什么了。',
      '半生闯荡，带来家业丰厚，儿孙满堂，行走一生的脚步，起点，终点，归根到底，都是家所在的地方，这是中国人秉持千年的信仰，朴素，但有力量',
      '我住长江头，君住长江尾；日日思君不见君，共饮长江水。 此水几时休？此恨何时已？ 只愿君心似我心，定不负相思意。',
      '如果有来生，要做一棵树，站成永恒，没有悲欢的姿势。一半在土里安详，一半在风里飞扬，一半洒落阴凉，一半沐浴阳光，非常沉默非常骄傲，从不依靠，从不寻找。',
      '春花秋月何时了，往事知多少。小楼昨夜又东风，故国不堪回首月明中。 雕栏玉砌应犹在，只是朱颜改。问君能有几多愁，恰似一江春水向东流。',
      '燕子去了，有再来的时候；杨柳枯了，有再青的时候；桃花谢了，有再开的时候。但是，聪明的，你告诉我，我们的日子为什么一去不复返呢？ 是有人偷了他们罢：那是谁？又藏在何处呢？是他们自己逃走了罢：现在又到了哪里呢？',
      '纤云弄巧，飞星传恨，银汉迢迢暗度。金风玉露一相逢，便胜却人间无数。柔情似水，佳期如梦，忍顾鹊桥归路，两情若是久长时，又岂在朝朝暮暮。',
      '小时候，乡愁是一枚小小的邮票，我在这头，母亲在那头。长大后，乡愁是一张窄窄的船票，我在这头，新娘在那头。后来啊，乡愁是一方矮矮的坟墓，我在外头，母亲在里头。而现在，乡愁是一湾浅浅的海峡，我在这头，大陆在那头。',
      '轻轻的我走了， 正如我轻轻的来； 我轻轻的招手， 作别西天的云彩。 那河畔的金柳，是夕阳中的新娘；波光里的艳影，在我的心头荡漾。',
      '我不去想，是否能够成功，既然选择了远方，便只顾风雨兼程。我不去想能否赢得爱情既然钟情于玫瑰就勇敢地吐露真诚。',
      '我听见回声，来自山谷和心间，以寂寞的镰刀收割空旷的灵魂，不断地重复决绝，又重复幸福，终有绿洲摇曳在沙漠。我相信自己，生来如同璀璨的夏日之花，不凋不败，妖冶如火，承受心跳的负荷和呼吸的累赘，乐此不疲。',
      '天上一个月亮，水里一个月亮。天上的月亮在水里，水里的月亮在天上。低头看水里，抬头看天上。看月亮，思故乡，一个在水里，一个在天上。',
      '春天的嫩叶， 一只只毛茸茸的手掌； 秋天的红叶， 一张张金黄的请贴。 春天请你去播种， 秋天请你去收获。 而冬天的雪片呢？ 送你一篇圣洁的童话， 赠你一片冬天的山野。',
      '当夜色降临，我站在台阶上倾听； 星星蜂拥在花园里，而我站在黑暗中。 听，一颗星星落地作响！ 你别赤脚在这草地上散步， 我的花园到处是星星的碎片。',
      '谁也没见过风，无论是你，无论是我。当树叶沙沙作响，那是风在吹拂。谁也没见过风，无论是你，无论是我。当树向你频频点头，那是风在吹过。'
    ],
    readingContent: ''
  },
  onLoad: function () {
    var _this = this;
    _this.setData({
      readingContent: _this.data.readingContentArr[parseInt(Math.random()*_this.data.readingContentArr.length)]
    });
    getRecordSetting(wx,_this);

    recorderManager.onStart(() => {
      console.log('onStart回调触发')
      _this.setData({
        isSpeaking: true,
        resultTxt: '',
        startTime: new Date().getTime()
      });
      timeCount = 0;
      speaking.call(_this);
    })

    recorderManager.onResume(() => {  //继续录音
      console.log('onResume回调触发');
      timeCount = this.data.count;
      _this.setData({
        isSpeaking: true,
        startTime: new Date().getTime()
      });
      speaking.call(_this);
    })

    recorderManager.onPause(() => {
      console.log('onPause回调触发');
      clearTimeout(_this.timer);
      console.log('onPause clearTimeout');
      _this.setData({
        isSpeaking: false,
        endTime: new Date().getTime(),
        resultTxt: '录音时间不足10秒，请继续录音'
      });
    })

    recorderManager.onStop(function(res){
      console.log('onStop回调触发');
      duringTime = 0;
      _this.setData({
        isSpeaking: false,
        endTime: new Date().getTime(),
        resultTxt: ''
      });

      //临时路径,下次进入小程序时无法正常使用
      const tempFilePath = res.tempFilePath;
      var userInfo = wx.getStorageSync('userInfo') || {};
      userInfo.file = tempFilePath;
      wx.setStorageSync('userInfo', userInfo);
      // clearInterval(_this.timer);
      // console.log('onStop clearInterval');
      clearTimeout(_this.timer);
      console.log('onStop clearTimeout');
      wx.redirectTo({
        url: '../analysing/analysing'
      });
    })
  },

  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '测测你声音中的秘密',
      desc: '用声纹守护你的平安!',
      path: '/pages/userName/userName',
      success: function(res) {
        // 转发成功
        console.log('转发成功');
      },
      fail: function(res) {
        // 转发失败
        console.log('转发失败');
      }
    }
  },

  tapFn: function () {
    var _this = this;
    // console.log("手指tap...clearInterval");
    // clearInterval(this.timer);
    clearTimeout(_this.timer);
    console.log('手指tap clearTimeout');
    if(_this.data.getRecord){  //已开启录音权限
      console.log('tap时已开启录音权限');
      this.setData({
        'isSpeaking': !this.data.isSpeaking
      });
      if(this.data.isSpeaking){  //开始录音
        console.log('isSpeaking: true;开始录音,显示录音时间');
        this.setData({
          countShow: true
        });
        console.log(duringTime);
        if(duringTime > 0){
          console.log('duringTime大于0继续录音');
          recorderManager.resume();
        }else{
          console.log('duringTime不大于0开始录音');
          recorderManager.start(options)
        }

      }else{  //结束录音
        console.log('isSpeaking: false;结束录音');
        duringTime = this.data.count*1000;
        console.log(duringTime)
        if(duringTime>=10000){
          console.log('duringTime>10000结束录音');
          recorderManager.stop();
        }else{
          console.log('duringTime<10000暂停录音');
          recorderManager.pause();
        }
      }
    }else{
      console.log('用户点击了录音按钮，但之前没授权录音权限，所以需引导用户开启');
      getRecordSetting(wx,_this)
    }

  }
});
function speaking() {
  clearTimeout(this.timer);
  var _this = this;
  // console.log('setIntervalBeforeSpeaking');
  // this.timer = setInterval(function () {
  //   var count = timeCount;
  //   timeCount=(parseFloat(count)+0.02).toFixed(2);
  //   _this.setData({
  //     count: timeCount
  //   });
  // },20)
  console.log('时间计时器开始计时: ' + timeCount);
  this.timer = setTimeout(function(){
    var count = timeCount;
    timeCount = (parseFloat(count) + 0.1).toFixed(1);
    _this.setData({
      count: timeCount
    });
    speaking.call(_this);
  },100);
}
function getRecordSetting(wx,_this) {
  console.log('获取用户是否开启录音权限');
  wx.getSetting({
    success(res) {
      console.log('获取用户是否开启录音权限成功');
      if (!res.authSetting['scope.record']) {
        console.log('是否开启录音权限: false');
        wx.authorize({
          scope: 'scope.record',
          success(res) {
            // 用户已经同意，后续调用不会弹窗询问
            console.log('用户同意开启录音权限');
            console.log(res)
            _this.setData({getRecord:true})
          },
          fail(res){
            console.log('用户不同意开启录音权限');
            console.log(res);
            wx.openSetting({
              success: (res) => {
                console.log('openSetting record');
                console.log(res.authSetting['scope.record']);
              }
            });
          }
        });
      }else{
        console.log('是否开启录音权限: true');
        _this.setData({getRecord:true})
      }

    },
    fail(res){
      console.log('获取用户是否开启录音权限 fail');
      console.log(res);
    }
  });
}
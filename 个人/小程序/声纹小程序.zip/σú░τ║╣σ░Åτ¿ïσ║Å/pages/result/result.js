 
var wxCharts = require('../../utils/wxcharts.js');
var app = getApp();
var radarChart = null;
Page({
  data: {
    username: '',
    voiceType: '',
    valueTxt: '你的声音魅力值为 ',
    valueTxt2: '',
    starArr: [],
    star1: '',
    star2: '',
    percent1: '',
    percent2: '',
    lang1: '',
    lang2: '',
    lang: [],
    qrCodePath: '',
    seriesData: [],
    categories: [],

  },
  onLoad: function (options) {

  },
  shareFn: function () {
    console.log('shareFn');
  },
  previewImage: function () {
    wx.navigateTo({
      url: '../canvas/canvas',
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '测测你声音中的秘密',
      desc: '用声纹守护你的平安!',
      path: '/pages/userName/userName',
      success: function (res) {
        // 转发成功
        console.log('转发成功');
      },
      fail: function (res) {
        // 转发失败
        console.log('转发失败');
      }
    }
  },
  againFn: function () {
    console.log('againFn');
    wx.redirectTo({
      // url: '../reading/reading'
      url: '../userName/userName'
    })
  },
  touchHandler: function (e) {
    console.log(radarChart.getCurrentDataIndex(e));
  },
  onReady: function (e) {
    var userInfo = wx.getStorageSync('userInfo') || {};
    var username = userInfo.username || '';
    var result = userInfo.result;
    var starNumber = result['charm'] || 0;
    var star = result['starArr'] || [];
    var starText = result['starText'] || '';
    var prop = result['prop'] || '';
    var valueArr = result['valueArr'] || [];
    var lang = result['lang'] || [];
    var seriesData = result['seriesData'] || [];
    var categories = result['categories'] || [];
    this.setData({
      starArr: new Array(starNumber),
      username: username,
      seriesData: seriesData,
      star1: star[0],
      star2: star[1],
      lang1: lang[0],
      lang2: lang[1],
      percent1: valueArr[0],
      percent2: valueArr[1],
      categories: categories,
      voiceType: prop,
      valueTxt2: starText
    });
    var _this = this;
    var windowWidth = 375;
    try {
      var res = wx.getSystemInfoSync();
      windowWidth = res.windowWidth;
      console.log(windowWidth)
    } catch (e) {
      console.error('getSystemInfoSync failed!');
    }

    radarChart = new wxCharts({
      canvasId: 'radarCanvas',
      type: 'radar',
      legend: false,
      // categories: ['萝莉 90 %', '呆萌 70 %', '女王 70 %', '暖男 60 %', '闷骚 50 ％', '威猛 40 %'],
      // categories: ["萝莉 31 %", "性感 34 %", "女王 24 %", "暖男 34 %", "逗比 31 ％", "阳刚 24 %"],
      categories: _this.data.categories,
      series: [{
        name: '',
        // data: [90, 70, 70, 60, 50, 40]
        data: _this.data.seriesData
      }],
      width: windowWidth,
      height: 180,
      extra: {
        radar: {
          gridColor: '#ffffff',
          labelColor: '#9701f9',
          max: 100
        }
      }
    });
  }
});

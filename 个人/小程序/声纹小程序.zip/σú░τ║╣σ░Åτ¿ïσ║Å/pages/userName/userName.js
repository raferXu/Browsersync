Page({
  data: {
    userInfo: {},
    musicList: {},
    musicInfo: {},
    hasMusic: 0,
    isPlay: 0,
    startBtn: '开始测试'
  },
  watchUsername(event){
    
  },
  // getUserName: function(e){
  //   console.log(e);
  //   var username = e.detail.value.username;
  //   if(!username){
  //     wx.showModal({
  //       title: '提示',
  //       content: '请输入姓名',
  //       success: function(res) {
  //         if (res.confirm) {
  //           console.log('用户点击确定')
  //         } else if (res.cancel) {
  //           console.log('用户点击取消')
  //         }
  //       }
  //     })
  //   }else{
  //     var userInfo = wx.getStorageSync('userInfo') || {};
  //     userInfo.username = username.replace(/[^\w\u4E00-\u9FA5]/g, '');
  //     wx.setStorageSync('userInfo', userInfo);
  //     wx.navigateTo({
  //       url: '../reading/reading'
  //     })
  //   }
  // },
  getName: function () {

    wx.getSetting({  // 可以通过 wx.getSetting 先查询一下用户是否授权
      success(res) {
        console.log(res.authSetting['scope.userInfo']);
        if (!res.authSetting['scope.userInfo']) {
          wx.authorize({
            scope: 'scope.userInfo',
            success(res) {
              // 用户已经同意，后续调用不会弹窗询问
              console.log('getSetting success');
              console.log(res)
            },
            fail(res){
              console.log('fail');
              console.log(res);
              wx.openSetting({
                success: (res) => {
                  console.log('openSetting');
                  console.log(res.authSetting['scope.userInfo']);
                  wx.getUserInfo({
                    success: function(res) {
                      var userInfo0 = res.userInfo;
                      var nickName = userInfo0.nickName;
                      var avatarUrl = userInfo0.avatarUrl;
                      var gender = userInfo0.gender; //性别 0：未知、1：男、2：女
                      var province = userInfo0.province;
                      var city = userInfo0.city;
                      var country = userInfo0.country;
                      var userInfo = wx.getStorageSync('userInfo') || {};
                      userInfo.username = nickName;
                      wx.setStorageSync('userInfo', userInfo);
                      console.log(wx.getStorageSync('userInfo'));
                      wx.navigateTo({
                        url: '../reading/reading'
                      })
                    },
                    fail: function () {
                      wx.showModal({
                        title: '警告',
                        content: '您点击了拒绝授权，将无法正常使用微信登录的功能体验。请再次点击授权，或者重新进入小程序。',
                        success: function (res) {
                          if (res.confirm) {
                            console.log('用户点击确定')
                          }
                        }
                      })
                    }
                  });
                }
              });
            }
          });
        }else{
          wx.getUserInfo({
            success: function(res) {
              var userInfo0 = res.userInfo;
              var nickName = userInfo0.nickName;
              var avatarUrl = userInfo0.avatarUrl;
              var gender = userInfo0.gender; //性别 0：未知、1：男、2：女
              var province = userInfo0.province;
              var city = userInfo0.city;
              var country = userInfo0.country;
              var userInfo = wx.getStorageSync('userInfo') || {};
              userInfo.username = nickName;
              wx.setStorageSync('userInfo', userInfo);
              console.log(wx.getStorageSync('userInfo'));
              wx.redirectTo({
                url: '../reading/reading'
              })
            }
          });
        }

      },
      fail(res){
        console.log('getSetting fail');
        console.log(res);
      }
    });
  },
  onLoad: function () {
    wx.login({
      success: function (res) {
        console.log('code is ' + res.code);
        wx.setStorage({ key: 'isCode', data: res.code});
        if (res.code) {
          // wx.request({
          //   url: 'https://api.weixin.qq.com/sns/jscode2session?appid=wxa39478f3e04014eb&secret=d1af0159de1f353bb367400634f48e11&js_code=' + res.code + '&grant_type=authorization_code',
          //   // data: {
          //   //   code: res.code
          //   // },
          //   // method: 'POST',
          //   header: {
          //     'content-type': 'application/x-www-form-urlencoded'
          //   },
          //   success: function (res) {
          //     console.log('res is ' + res)
          //     console.log('openid is ' + res.data.openid);
          //     wx.setStorage({ key: 'userId', data: res.data.openid });
          //   },
          //   fail: function (res) {
          //     console.log(res);
          //   }
          // })
        }
      }
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '自定义转发标题',
      path: '/page/user?id=123',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
});

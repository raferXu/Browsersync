// pages/canvas/canvas.js
import util from '../../utils/util'
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var userInfo = wx.getStorageSync('userInfo') || {};
    var username = userInfo.username || '';
    var result = userInfo.result;
    var voiceType = result['prop'] || '';
    var star1 = result['starArr'][0] || [];
    var star2 = result['starArr'][1] || [];
    var percent1 = result['valueArr'][0] || [];
    var percent2 = result['valueArr'][1] || [];
    var starText = result['starText'] || '';

    const ctx = wx.createCanvasContext("myCanvas")
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, 375, 603)

    ctx.drawImage("./image/bg_share2.png", 0, 0, 375, 603)

    ctx.setFontSize(20);
    ctx.setFillStyle("#ff01d0");
    ctx.fillText(username + ' :', 50, 87)

    ctx.setFontSize(16);
    ctx.setFillStyle("#fff");
    ctx.fillText("你的声音属性为", 130, 150)

    ctx.setFontSize(20);
    ctx.setFillStyle("#ff01d0");
    ctx.fillText(voiceType, 135, 180)

    ctx.setFontSize(16);
    ctx.setFillStyle("#fff");
    ctx.fillText('你与' + star1 + '的声音相似度达到了' + percent1 + '% !!', 50, 220)
 

    ctx.setFontSize(16);
    ctx.setFillStyle("#fff");
    ctx.fillText(starText, 50, 250)


    ctx.draw(true, function () {
      console.log("draw callback success")
      wx.canvasToTempFilePath({
        x: 0,
        y: 0,
        width: 375,
        height: 603,
        destWidth: 750,
        destHeight: 1206,
        canvasId: 'myCanvas',
        success: function (res) {
          console.log("get tempfilepath(success) is:", res.tempFilePath)
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success(res) {
              console.log(res);
              wx.showModal({
                title: '保存成功！',
                content: '分享朋友圈方法：切换到微信上，分享朋友圈时选择此图即可',
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  } 
                }
              })              },
            fail(res) {
              console.log(res)
              wx.showModal({
                title: '啊哦',
                content: '你不要留着给朋友们看看吗',
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })              }
          })
        }
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '测测你声音中的秘密',
      desc: '用声纹守护你的平安!',
      path: '/pages/userName/userName',
      success: function (res) {
        // 转发成功
        console.log('转发成功');
      },
      fail: function (res) {
        // 转发失败
        console.log('转发失败');
      }
    }
  },
})
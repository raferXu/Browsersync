<script>  
  const BASE_URL = 'http://192.168.0.143:1987';  
  // const BASE_URL = 'http://192.168.0.203:5000';  
  export default{  
    BASE_URL  
  }  
</script> 
<template lang="html"  >
  <div ref='bgImg' :style="backgroundDiv" @keyup='entreLogin'>
    <el-col :span='6' :offset='8' style='margin-top:100px;margin-left:37%' v-loading.body="loading">
      <div style='background:#fff;box-shadow: 10px 10px 5px #ddd'>
        <el-row>
          <img :src="imgLog" alt="" width="30%"  id='login_img' style='margin-top:10%;margin-bottom:10%'>
        </el-row>
        <span>登录平安众包</span>
        <el-form :model="ruleForm2" :rules="rules2" ref="ruleForm2" label-width="0px" class="demo-ruleForm" style='margin:0 8%;'>
          <el-form-item label="" prop="checkPass" style='margin-top:30px;'>
            <el-radio-group   v-model="radio3" @change='selectSystem'>
                <el-radio-button label="后台系统"></el-radio-button>
                <el-radio-button label="发票系统"></el-radio-button>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="" prop="checkPass" style=''>
            <el-input  size='small' type="text" v-model="ruleForm2.checkPass" auto-complete="off" id='login_username' placeholder='账号'></el-input>
          </el-form-item>
          <el-form-item label="" prop="pass" >
            <el-input  size='small' type="password" v-model="ruleForm2.pass" auto-complete="off" id='login_password' placeholder='密码'></el-input>
          </el-form-item>
          <el-form-item style='margin-top:-20px;margin-bottom:-1px'>
            <el-checkbox size='large' style='float:right' v-model='oRemember' @change='change'><span style='font-size:8px'>记住密码</span></el-checkbox>
          </el-form-item>
          <el-form-item>
            <el-button   type="primary" @click="submitForm('ruleForm2')" style='width:100%;margin-bottom:50px;background:#ff6000;border:none' id='login_btn'>登录</el-button>
          </el-form-item>
        </el-form>
      </div>

    </el-col>
  </div>
</template>

<script>
import getDate from '@/components/common/js/getDate.js'
export default {
  mounted() {
    if (this.getCookie('user') && this.getCookie('pswd')) {
      this.ruleForm2.checkPass = this.getCookie('user');
      this.ruleForm2.pass = this.getCookie('pswd');
      this.oRemember = true;
    }
    this.backgroundDiv.height = window.innerHeight - 20 + 'px'
    let self = this
    window.onresize = function() {
      if (window.innerHeight - 20 > 500) {
        self.backgroundDiv.height = window.innerHeight - 20 + 'px'
      }
    }
  },
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'));
      } else {
        if (this.ruleForm2.checkPass !== '') {
          this.$refs.ruleForm2.validateField('checkPass');
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入账号'));
      } else {
        callback();
      }
    };
    return {
      radio3:'后台系统',
      imgLog: 'static/登录界面logo.png',
      oRemember: false,
      backgroundDiv: {
        background: 'url(' + require('./background.png') + ') no-repeat center center',
        height: '635px'
      },
      loading: false,
      ruleForm2: {
        pass: '',
        checkPass: '',
        age: ''
      },
      rules2: {
        pass: [
          { validator: validatePass, trigger: 'blur' }
        ],
        checkPass: [
          { validator: validatePass2, trigger: 'blur' }
        ],
      }
    };
  },
  methods: {
    entreLogin(ev) {
      if (ev.keyCode == 13) {
        this.submitForm('ruleForm2')
      }
    },
    submitForm(formName) {
      let self = this
      this.$refs[formName].validate((valid) => {
        if (valid) {
          self.loading = true
          let url = this.radio3=='发票系统'?'/token/user/signin':'token/manage/user/signin'
          let params = {
            "account": self.ruleForm2.checkPass,
            "password": self.ruleForm2.pass
          }
          self.axios({
            method: 'post',
            url: url,
            data: params
          }).then(function(response) {
            self.loading = false
            console.log(response)
            let res = response.data
            if (res.code == 200) {
              if (self.oRemember) {
                self.setCookie('user', self.ruleForm2.checkPass, 7); //保存帐号到cookie，有效期7天
                self.setCookie('pswd', self.ruleForm2.pass, 7); //保存密码到cookie，有效期7天
              }
              localStorage.token = res.body.token
              localStorage.username = res.body.username
                self.$router.push({ name: self.radio3=='发票系统'?'bill':'index' })
            } else if (res.code == 612) {
              self.$alert('账号或密码错误,请重新输入', '账号/密码错误', {
                confirmButtonText: '确定',
              });
            } else if (res.code == 909) {
              self.$alert('不是管理员账户,没有登陆权限', '账号没有授权', {
                confirmButtonText: '确定',
              });
            }
          }, function(error) {
            self.loading = false
            console.log(error)
            // 在此处处理特定业务错误: 
            console.log(error.msg)
            // 问题是: 当我在拦截器里处理了验证失效后, 它还是会执行到这里面
          })



        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    change() {
      if (!this.oRemember) {
        this.delCookie('user');
        this.delCookie('pswd');
      }
    },
    setCookie(name, value, day) {
      var date = new Date();
      date.setDate(date.getDate() + day);
      document.cookie = name + '=' + value + ';expires=' + date;
    },
    getCookie(name) {
      var reg = RegExp(name + '=([^;]+)');
      var arr = document.cookie.match(reg);
      if (arr) {
        return arr[1];
      } else {
        return '';
      }
    },
    delCookie(name) {
      this.setCookie(name, null, -1);
    },
    selectSystem(val){
      console.log(this.radio3)
    },
  }
}
</script>

<style lang="css">
.el-message-box {
  z-index: 30000;
}
</style>



// WEBPACK FOOTER //
// login.vue?065cdbe7
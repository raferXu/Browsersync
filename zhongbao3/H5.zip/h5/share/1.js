/**
 * Created by raferxu on 17/7/25.
 */
// define(function () {
//   return {};
// });

var btn = document.getElementById('btn');
btn.onclick = function () {
  alert('click');
}
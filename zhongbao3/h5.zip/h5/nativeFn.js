/**
 * Created by raferxu on 17/7/14.
 */
var jobTask = {};
jobTask.taskGuide = function () {
  alert('任务指引暂时不能查看');
};
jobTask.launchLoginPage = function () {
  alert('正在跳到登录页面');
};
jobTask.lotteryConfigInterval = function () {
  alert('抽奖系统故障');
};
jobTask.checkTaskStatistics = function () {
  alert('任务数据页面不能查看');
};
jobTask.notifyToRelogin = function () {
  alert('异地登录了');
};
jobTask.refreshCurrentPage = function () {
  alert('任务做完了');
};
jobTask.launchMessageCenterPage = function () {
  alert('消息中心暂时看不了');
};
jobTask.launchRankingPage = function () {
  alert('排行榜现在看不了');
};